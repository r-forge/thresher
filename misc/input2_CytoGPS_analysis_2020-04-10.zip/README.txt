Relative Path to Results		Input Karyotype

Line_1	->	46,XY,-8,+12,der(14)
Line_2	->	48,XY,t(10;13)(q26;q14),+12,+19/47,XY,t(9;13)(p24;q13),-10,+12,+19/45,XY,-13
Line_3	->	47,XY,+12,dup(14)(q32q32)


How to use Aggregate Loss-Gain-Fusion

To help biomedical data scientists conduct further analyses, we provide an aggregate csv file, which contains biologically important quantitative data, i.e., a tally of the cytogenetic events (loss, gain, and fusion) occurring at all G-850 bands (or subbands) in the chromosome. Several comments are worth noting:
i) Data is calculated at the clone level; a typical karyotype without subclones is regarded as a single-clone karyotype.
ii) Data is calculated for both a) correct karyotypes and b) the karyotypes which contain fixable grammar errors but contain no validation errors after the corrections the software has applied.
iii) The Karyotype_Revised column indicates whether the Loss-Gain-Fusion analysis is based on the original input or revised karyotype.
iv) For more detailed results of each line, please open the folder of the corresponding line number; each line has its own folder, even if that line has a karyotype which contains either a) nonfixable grammar errors or b) fixable grammar errors and validation errors after the corrections the software has applied.



How to use Summary Statistics

We provide summary statistics to help researchers understand the aberrancy percentage (AP) of the biological events (loss, gain, and fusion) for all chromosome bands or subbands. That is, for each chromosome band and/or subband, three aberrancy percentages will be calculated:
i) aberrancy percentage of loss (APL),
ii) aberrancy percentage of gain (APG), and
iii) aberrancy percentage of fusion (APF).

To be specific, we calculate each of these three percentages as follows:

Step 1: Count the total number of parsable clones (TNPC).
The number of clones contained in each karyotype will be added to TNPC, unless the karyotype contains unfixable grammar errors or validation errors.

Step 2: Count the total aberrancy number of the biological events (loss, gain, and fusion) for all chromosome bands or subbands.
For each chromosome band or subband, we increase its total aberrancy number of loss (TANL) by one, only if the number of loss occurring at this band or subband in a Loss-Gain-Fusion clone-specific result is greater than 0. Total aberrancy number of gain (TANG) and total aberrancy number of fusion (TANF) are calculated in a similar logic.

Step 3: Calculate the aberrancy percentages: APL, APG, and APF.
For each chromosome band or subband, calculate the three aberrancy percentages as below:
i) APL = TANL / TNPC,
ii) APG = TANG / TNPC, and
iii) APF = TANF / TNPC.
